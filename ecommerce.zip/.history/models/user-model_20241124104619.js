//creating the user model schema
