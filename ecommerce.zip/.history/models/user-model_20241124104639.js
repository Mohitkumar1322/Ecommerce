//creating the user model schema
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/express-auth', {