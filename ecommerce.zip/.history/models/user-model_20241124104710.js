//creating the user model schema
const mongoose = require('mongoose');

mongoose.connect("mongodb://127")