//creating the user model schema
const mongoose = require('mongoose');



const productSchema = new mongoose.Schema({
 
    
});


module.exports = mongoose.model('User', productSchema);
